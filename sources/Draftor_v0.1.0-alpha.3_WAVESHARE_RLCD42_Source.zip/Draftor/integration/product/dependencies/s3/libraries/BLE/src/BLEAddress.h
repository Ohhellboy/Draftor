/*
 * Copyright 2017-2026 Espressif Systems (Shanghai) PTE LTD
 * Copyright 2020-2025 Ryan Powell <ryan@nable-embedded.io> and
 * esp-nimble-cpp, NimBLE-Arduino contributors.
 * Copyright 2017 Neil Kolban
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * BLEAddress.h
 *
 *  Created on: Jul 2, 2017
 *      Author: kolban
 *
 *  Modified on: Feb 18, 2025
 *      Author: lucasssvaz (based on kolban's and h2zero's work)
 *      Description: Added support for NimBLE
 */

#ifndef COMPONENTS_CPP_UTILS_BLEADDRESS_H_
#define COMPONENTS_CPP_UTILS_BLEADDRESS_H_

#include "soc/soc_caps.h"
#include "sdkconfig.h"
#if defined(SOC_BLE_SUPPORTED) || defined(CONFIG_ESP_HOSTED_ENABLE_BT_NIMBLE)
#if defined(CONFIG_BLUEDROID_ENABLED) || defined(CONFIG_NIMBLE_ENABLED)

/***************************************************************************
 *                           Common includes                               *
 ***************************************************************************/

#include "WString.h"
#if SOC_BLE_SUPPORTED
#include <esp_bt.h>
#endif
#include <string>

/***************************************************************************
 *                           Bluedroid includes                            *
 ***************************************************************************/

#if defined(CONFIG_BLUEDROID_ENABLED)
#include <esp_gap_ble_api.h>
#endif

/***************************************************************************
 *                     NimBLE includes and definitions                     *
 ***************************************************************************/

#if defined(CONFIG_NIMBLE_ENABLED)
#include <nimble/ble.h>
#define ESP_BD_ADDR_LEN BLE_DEV_ADDR_LEN
#endif

/***************************************************************************
 *                            NimBLE types                                 *
 ***************************************************************************/

#if defined(CONFIG_NIMBLE_ENABLED)
typedef uint8_t esp_bd_addr_t[ESP_BD_ADDR_LEN];
#endif

/**
 * @brief A %BLE device address.
 *
 * Every %BLE device has a unique address which can be used to identify it and form connections.
 */
class BLEAddress {
public:
  /***************************************************************************
   *                       Common public declarations                        *
   ***************************************************************************/

  BLEAddress();
  bool equals(const BLEAddress &otherAddress) const;
  bool operator==(const BLEAddress &otherAddress) const;
  bool operator!=(const BLEAddress &otherAddress) const;
  bool operator<(const BLEAddress &otherAddress) const;
  bool operator<=(const BLEAddress &otherAddress) const;
  bool operator>(const BLEAddress &otherAddress) const;
  bool operator>=(const BLEAddress &otherAddress) const;
  uint8_t *getNative();
  uint8_t getType() const;
  void setType(uint8_t type);
  String toString() const;

  /***************************************************************************
   *                       Bluedroid public declarations                     *
   ***************************************************************************/

#if defined(CONFIG_BLUEDROID_ENABLED)
  BLEAddress(esp_bd_addr_t address, uint8_t type = 0);
  BLEAddress(const String &stringAddress, uint8_t type = 0);
#endif

  /***************************************************************************
   *                       NimBLE public declarations                        *
   ***************************************************************************/

#if defined(CONFIG_NIMBLE_ENABLED)
  BLEAddress(ble_addr_t address);
  BLEAddress(const String &stringAddress, uint8_t type = BLE_ADDR_PUBLIC);
  BLEAddress(uint8_t address[ESP_BD_ADDR_LEN], uint8_t type = BLE_ADDR_PUBLIC);
#endif

private:
  /***************************************************************************
   *                       Common private properties                         *
   ***************************************************************************/

  uint8_t m_address[ESP_BD_ADDR_LEN];
  uint8_t m_addrType;
};

#endif /* CONFIG_BLUEDROID_ENABLED || CONFIG_NIMBLE_ENABLED */
#endif /* SOC_BLE_SUPPORTED || CONFIG_ESP_HOSTED_ENABLE_BT_NIMBLE */

#endif /* COMPONENTS_CPP_UTILS_BLEADDRESS_H_ */

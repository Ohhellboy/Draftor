> Historical Alpha 2.1 original-board documentation. Current Waveshare instructions are in [INSTALL](INSTALL.md); do not mix target images.

# 草稿机 Alpha 2.1：中文查找与界面更新

[English](RELEASE_NOTES.md) | **简体中文**

Alpha 2.1 加入了支持中文输入的查找界面，并整理了草稿机的中文菜单和编辑器状态栏。查找界面跟随横排、竖排写作方向；文件名、输入方式、保存和连接状态也有了更简洁的显示。

## 这次改了什么

- **在文稿中查找中文和英文。** 按 `Ctrl+F` 或 `Cmd+F` 打开查找，输入要找的文字。完成选词后，按 `Enter` 查找下一处，按 `Shift+Enter` 查找上一处，到文稿边界后可以回绕。查询框里的输入不会改动正文。
- **用中文管理文稿。** 文件列表、回收站、重命名、统计、帮助，以及 USB 和 Wi-Fi 页面采用中文提示。长文件名可以展开查看，改名框也支持用 Shift 选择一部分文字，再替换或删除。
- **让写作画面更简洁。** 顶部只保留文件名；底部左侧用 `En／双／全／五` 表示输入方式，右侧显示保存和蓝牙状态。横排文件名移到原模式栏位置，正文区域随之向上扩展。正在输入的编码、候选、错误提示和配对验证码仍会在需要时显示。

为了配合这些界面变化，本版还修正了局部选择、竖排查找提示和返回菜单时的若干交互细节，并减少了长名排版中的重复测量。构建中也调整了字符串实现的链接次序，减少固件占用。具体操作见[使用手册](USAGE.zh-CN.md)。

## 下载哪些文件

ESP32-S3 N16R8（Thick）用户安装时，下载同一版本的 **Firmware** 和 **Resources**。需要自行编译时，再下载 **Source** 与 **BuildInputs**。

| 文件 | 用途 |
| --- | --- |
| `Firmware.zip` | App、启动与分区文件、安装指南及离线检查工具 |
| `Resources.zip` | 配套 TF 词库、索引和正文字体 |
| `Source.zip` | Draftor、bgIME、相关源码和文档 |
| `BuildInputs.zip` | 编译所需的生成字形、固定依赖及来源材料 |

GitHub 自动生成的 Source code 压缩包只是仓库快照。安装设备请按 Firmware 中的指南使用配套附件；自行编译请参考[构建指南](BUILD.md)。

## 从旧版升级

**Alpha 2 用户：** 本版沿用双 4 MiB App 分区和原 format4 TF 资源。先保存并备份文稿，再读取设备的分区和启动记录；确认兼容后，按[安装指南](INSTALL_ALPHA2_1.zh-CN.md)只更新当前 App。无需为了这次界面更新重装词库或格式化 TF 卡。

**Alpha 1、旧 2 MiB 槽或首次安装：** 本版 App 放不进旧槽，因此需要使用指南中的全新安装流程。全新安装会清除内部 Flash，须先备份所需数据；它不会要求格式化 TF 卡。

## 仍需注意

Alpha 2.1 仍是测试版本，本地 Wi-Fi 传输也仍属实验功能。重要文稿请定期导出备份。

文稿较多时，文件列表和部分管理操作可能变慢。建议定期将不再编辑的文稿导出归档；回收站也参与目录规模，移入回收站不能减少这个总量。具体边界见[已知问题](KNOWN_ISSUES.md)。

字体和词库各自的来源及许可见[资源说明](RESOURCE_STATUS.md)。此前的中文输入速度测量仍属于 [Alpha 2](RELEASE_NOTES_ALPHA2.zh-CN.md)，完整结果保留在[性能报告](PERFORMANCE.md)。

# Draftor Alpha 3 limitations / 已知限制

微雪首批仅覆盖 ST7305、180°。新增学习索引、文稿位置与升级备份见[安装](INSTALL.zh-CN.md)。已验收范围及全新空板首装边界见[实机记录](ALPHA3_VALIDATION.md)。Wi-Fi 文稿传输仍属实验功能。

## Historical Alpha 2.2 observations / 历史记录


Alpha 2.2 adds the Waveshare target while retaining Chinese Find and interface labels. Keep independent exports of important manuscripts. The limits below apply to the current product; historical measurements retain their original version names.

Alpha 2.2 增加微雪目标并保留中文查找及界面。使用时仍请独立导出重要文稿。以下说明当前限制；历史测量保留原版本归属。

## Waveshare Alpha 2.2 / 历史微雪范围

The accepted R5 F-01 input-stall finding is closed only for the tested Waveshare board, Logitech keyboard and Fn configuration. No new keyboard-internal or air-interface evidence is claimed. HOGP all-Input subscriptions and CCCD readback stay enabled independently of diagnostics. Menu footer overlap is fixed; no quantified trash performance claim is made.

R5 had one reboot “存储异常” observation without a captured status/stage. Host reproduction proves a narrower issue: a valid imported body/CURRENT with no optional position record returned `OK_DEGRADED / position_fallback`. Alpha 2.2 uses the snapshot's valid default cursor and returns `OK / position_default` only for `NOT_FOUND`. Corruption, mismatch, I/O, genuine body/metadata recovery and PARTIAL still warn. This is not proof of the historical event's exact cause. See [Alpha 2.2 hardware qualification](ALPHA2_2_VALIDATION.md) for the final unedited import/reboot/export outcome.

历史警告的实际分支未知；本轮不把“提示消失”当作数据安全证明。正常位置缺省与真实损坏分开处理；真实警告仍须留证。原机也编译验证这项共享修改，但没有新原机实测或可刷发行资产。

Waveshare qualification is USB-powered, on the same tested keyboard and Linux/Pi USB host. Battery/PWR shutdown semantics, long stress, other cards/keyboards/hosts, new-board fresh installation and Wi-Fi/QR exchange remain limited or untested. Wi-Fi/QR stays available as an inherited experiment; original-board evidence is not relabelled as Waveshare evidence. No automatic TF repair or namespace adoption is provided.

## Large libraries / 大文库

The catalog keeps up to 128 complete metadata entries in RAM. Normal manuscripts and trash both contribute to that catalog size. Beyond the cache boundary, opening the list, paging, restoring or renaming can require repeated scans and become noticeably slow. 128 is a cache boundary, not a manuscript limit; large-library performance remains open.

目录在 RAM 中缓存最多128项完整元数据，正常文稿和回收站共同参与这个规模。超过缓存容量后，打开列表、分页、恢复或改名可能反复扫描目录，因此会明显变慢。128是缓存边界，不是文稿硬上限；大文库性能仍待改进。

Export finished writing regularly. Moving it to the trash does not reduce the combined count. There is currently no public bulk-archive or permanent-delete workflow; do not delete internal records or edit META/CURRENT by hand to make the library smaller.

建议定期导出已完成的文稿。移入回收站不能减少总数；当前也没有面向用户的批量归档或永久删除流程。不要为了缩小文库而手工删除内部记录、修改 META 或 CURRENT。

## Current limits / 当前限制

- **2 MiB slots cannot accept this App.** Alpha 1 users should back up manuscripts and necessary data, erase internal flash, and follow the original-board [fresh-install procedure](INSTALL_ALPHA2_1.md). The TF card does not need formatting. / 旧2 MiB槽装不下本版；Alpha 1 用户请先备份，清除内部 Flash 后全新安装，不格式化 TF 卡。
- Resources must be the exact format4 set; format2 files/Ready markers do not make a mixed directory compatible. / 不混用旧新资源或伪造 Ready。
- Some activation/warm-query costs and synchronous full-screen blocking remain; see [Performance](PERFORMANCE.md). / 激活、热查询子段及同步整屏仍有代价。
- User-frequency learning, personal dictionaries, abbreviated/mixed Pinyin, selectable fonts and complete Pico writing firmware remain unavailable. Chinese Find and the current Chinese menus are described in the user guide. / 用户词频学习、个人词库、简拼混拼、字体切换和 Pico 整机固件仍未提供；中文查找及现有中文菜单见使用手册。
- Experimental F10 local Wi-Fi transfer and QR pages exist in the fixed image; Wi-Fi starts off, Esc returns to writing without turning it off, and F10 then O turns it off. The performance and FW1 evidence covers Wi-Fi off. / F10实验热点/二维码已在固件；Esc不关热点，F10后O关闭，本轮性能证据覆盖关闭状态。

## Serial diagnostics / 串口诊断

The author requested removing serial composition-code and input-timing observation from the release. Its build sets `DRAFTOR_AUTH_OBSERVE=0`, telemetry profile 0 and capture 1: `ui_trace.cpp::traceUi` returns before recording input events, `service_endpoints.cpp` is excluded by its existing guard, and `device_main.cpp::idleDiagnostics` returns without draining an input stream. The ordinary diagnostic command parser is also disabled in this configuration. The target check rejects linked observer symbols and SW/input-text format strings.

作者已决定发行版关闭组成码与输入计时观察。沿用现有编译开关关闭采集/排出路径，并检查实际链接镜像中没有对应观察符号和格式字符串；没有重写输入法业务。

Startup/build identity, connection, memory/health and error diagnostics remain on the serial port; it is not a silent port. No persistent input-log writer is introduced. Review diagnostic output before sharing it. The earlier measured baseline did emit composition codes automatically and remains privately retained as comparison evidence; its image is not substituted for this release App.

串口仍保留启动标识、连接、内存/运行状态及错误诊断，不是完全静默；没有新增持久输入日志。分享诊断前仍应检查内容。此前实测基线确实默认输出组成码，作为原证据单独保留，不拿它替代这份发行App。

## Historical observations still open / 历史未彻底解释的现象

An intermittent first `n` in a longer Pinyin input was reported in earlier sessions; the latest finite session does not establish a general fix. Earlier display splitting/distortion under a different, unadopted coordination candidate is not a confirmed current format4/synchronous-delta fault. Both remain historical observations, not claims that every current input fails. Retained candidate/session assertion failures and missing hot-path observations are listed in the technical performance notes; packaging did not weaken those tests.

此前曾报告较长拼音中首次 `n` 未及时出现，后续有限会话不能作为普遍修复结论。旧未采纳协同候选上的分半/扭曲也不等于当前版已复现故障。旧断言失败及热路径缺项继续列账，本轮未放宽断言。

## Not fully qualified / 尚未充分覆盖

Long continuous use, unexpected power interruption during every storage phase, extreme memory pressure, different cards/keyboards/power arrangements, fresh-board installation and arbitrary cross-version downgrade remain incompletely qualified. Current software support uses the original external-power prototype; this release does not make a new claim about battery hardware. Existing USB save/export/reopen evidence and earlier Wi-Fi/QR software and device evidence are retained; the latest performance and free-writing sessions kept Wi-Fi off. See the [inherited Wi-Fi evidence and remaining gaps](WIFI_STATUS.md).

长期连续使用、存储各阶段断电、极限内存、不同卡/键盘/供电、新空板及任意降级尚未全面覆盖。软件范围沿用原外部供电原型，不推断电池硬件的新状态。USB保存导出重开及此前 Wi-Fi/二维码的软件、实机证据继续沿用；后续性能和自由写作会话保持 Wi-Fi 关闭。具体范围见[既有 Wi-Fi 证据与缺项](WIFI_STATUS.md)。

Report a short reproducible example, version and hardware details via [Issues](https://github.com/Ohhellboy/Draftor/issues). You do not need to upload a manuscript, full serial log or flash backup. Third-party provenance questions remain in [Resource Status](RESOURCE_STATUS.md).

反馈时提供简短复现、版本及硬件信息即可，不需上传私人稿、整段串口或 Flash备份。[资源来源未决事项](RESOURCE_STATUS.md)另列。

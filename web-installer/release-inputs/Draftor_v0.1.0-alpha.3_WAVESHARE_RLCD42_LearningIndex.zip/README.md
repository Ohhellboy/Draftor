# Draftor Alpha 3 · 微雪通用学习索引 / Waveshare learning index

将 `Resources/WAVESHARE_R7_L1_AREV1_RES_20261112/` 整个目录复制到 TF 卡根目录。保留卡上的文稿和学习记录。通用词库与字体使用[指定历史资源包](https://github.com/Ohhellboy/Draftor/releases/download/v0.1.0-alpha.2.1/Draftor_v0.1.0-alpha.2.1_Resources.zip)。卡上全部 18 项输入的路径、长度及 SHA-256 见 `Resources/TF_RESOURCES.json`。

Copy the complete index directory above to the TF card root. The two files contain dictionary row references and authentication data. Back up your existing manuscripts and learning directory before changing your card.

[中文安装](https://github.com/Ohhellboy/Draftor/blob/v0.1.0-alpha.3/docs/INSTALL.zh-CN.md) · [Installation](https://github.com/Ohhellboy/Draftor/blob/v0.1.0-alpha.3/docs/INSTALL.md) · [资源来源 / Provenance](https://github.com/Ohhellboy/Draftor/blob/v0.1.0-alpha.3/docs/RESOURCE_STATUS.md)
